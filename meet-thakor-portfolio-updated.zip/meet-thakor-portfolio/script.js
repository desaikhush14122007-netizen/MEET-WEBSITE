const toggle = document.getElementById('menuToggle');
const nav = document.getElementById('nav');

// Mobile navigation
toggle?.addEventListener('click', () => {
  const open = nav.classList.toggle('open');
  toggle.setAttribute('aria-expanded', String(open));
});
nav?.querySelectorAll('a').forEach(link => link.addEventListener('click', () => {
  nav.classList.remove('open');
  toggle?.setAttribute('aria-expanded', 'false');
}));
document.addEventListener('keydown', event => {
  if (event.key === 'Escape') {
    nav?.classList.remove('open');
    toggle?.setAttribute('aria-expanded', 'false');
    closeLightbox();
  }
});

// Reveal content as it enters the viewport
const revealEls = document.querySelectorAll('.section-head,.project,.manifesto p,.about-copy,.about-visual,.service-list article,.approach,.contact h2,.contact-bottom');
revealEls.forEach(el => el.classList.add('reveal'));
if ('IntersectionObserver' in window) {
  const observer = new IntersectionObserver(entries => entries.forEach(entry => {
    if (entry.isIntersecting) { entry.target.classList.add('visible'); observer.unobserve(entry.target); }
  }), { threshold: 0.12 });
  revealEls.forEach(el => observer.observe(el));
} else revealEls.forEach(el => el.classList.add('visible'));

// Subtle cursor light and 3D hero tilt (desktop pointer only)
const glow = document.querySelector('.cursor-glow');
const heroVisual = document.querySelector('.hero-visual');
const heroCard = document.querySelector('.hero-image-wrap');
const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
window.addEventListener('pointermove', event => {
  if (event.pointerType !== 'mouse' || reduceMotion) return;
  if (glow) { glow.style.left = `${event.clientX}px`; glow.style.top = `${event.clientY}px`; }
  if (heroVisual && heroCard && window.innerWidth > 640) {
    const rect = heroVisual.getBoundingClientRect();
    const x = (event.clientX - rect.left) / rect.width - 0.5;
    const y = (event.clientY - rect.top) / rect.height - 0.5;
    heroCard.style.transform = `rotateY(${-5 + x * 9}deg) rotateX(${2 - y * 7}deg) translateZ(8px)`;
  }
});
heroVisual?.addEventListener('pointerleave', () => { if (heroCard) heroCard.style.transform = ''; });

// Accessible project image lightbox
const lightbox = document.getElementById('lightbox');
const lightboxImage = document.getElementById('lightboxImage');
const lightboxCaption = document.getElementById('lightboxCaption');
const lightboxClose = document.getElementById('lightboxClose');
function closeLightbox() {
  if (!lightbox) return;
  lightbox.classList.remove('open');
  lightbox.setAttribute('aria-hidden', 'true');
  document.body.style.overflow = '';
  if (lightboxImage) lightboxImage.src = '';
}
document.querySelectorAll('.project-image:not(.project-external)').forEach(link => {
  link.addEventListener('click', event => {
    if (!lightbox || !lightboxImage) return;
    event.preventDefault();
    const image = link.querySelector('img');
    lightboxImage.src = link.href;
    lightboxImage.alt = image?.alt || 'Selected project frame';
    if (lightboxCaption) lightboxCaption.textContent = image?.alt || 'Selected project';
    lightbox.classList.add('open');
    lightbox.setAttribute('aria-hidden', 'false');
    document.body.style.overflow = 'hidden';
    lightboxClose?.focus();
  });
});
lightboxClose?.addEventListener('click', closeLightbox);
lightbox?.addEventListener('click', event => { if (event.target === lightbox) closeLightbox(); });

// Current section indicator
const sections = document.querySelectorAll('main section[id]');
if ('IntersectionObserver' in window) {
  const sectionObserver = new IntersectionObserver(entries => entries.forEach(entry => {
    if (!entry.isIntersecting) return;
    nav?.querySelectorAll('a').forEach(link => {
      if (link.getAttribute('href') === `#${entry.target.id}`) link.setAttribute('aria-current', 'location');
      else link.removeAttribute('aria-current');
    });
  }), { rootMargin: '-35% 0px -55% 0px' });
  sections.forEach(section => sectionObserver.observe(section));
}
