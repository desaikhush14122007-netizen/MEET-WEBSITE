# Meet Thakor — andekhi.nigaahen Portfolio

A complete responsive portfolio website built with semantic HTML, a separate CSS stylesheet, and vanilla JavaScript. The original project visuals extracted from the supplied five-page PDF are included in `assets/`.

## Run the website

1. Extract `meet-thakor-portfolio.zip`.
2. Open the `khushverse-portfolio` folder in VS Code.
3. Confirm `index.html`, `style.css`, `script.js`, and `assets/` stay together.
4. Right-click `index.html` and choose **Open with Live Server** (or double-click it to open directly in a browser).

No npm install, build command, or framework is required. Google Fonts need an internet connection; local fallback fonts are included.

## Working features

- Separate, linked `style.css` and `script.js` files
- Responsive desktop, tablet, and mobile layouts
- Mobile navigation with close-on-select and Escape support
- Scroll reveal animations and active-section navigation
- Subtle desktop 3D hero tilt and cursor light
- Click-to-expand project image lightbox with Escape and backdrop close
- Keyboard skip link and reduced-motion support
- Project image links and in-page navigation
- Third selected project links directly to the supplied Instagram reel

## Contact details included

- Call: `+91 82003 89836`
- WhatsApp: `https://wa.me/918200389836`
- Email: `meetthakor0911@gmail.com`
- Instagram: `https://www.instagram.com/_meet_0911_/`
- Instagram QR image: `assets/instagram-qr.jpeg`

The contact links are live, and the QR card opens the Instagram profile. Update the corresponding anchors in `index.html` if these details change.

## Edit the design

- Content and project labels: `index.html`
- Colors, typography, layout, responsive breakpoints, and animations: `style.css`
- Navigation, lightbox, scroll effects, and 3D pointer interaction: `script.js`
- Portfolio images: `assets/`
